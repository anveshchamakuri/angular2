export interface empdetails{
    empid : number,
    empname : string,
    gender : string,
    salary : number,
    promoted():boolean
}