import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fullviewdata',
  templateUrl: './fullviewdata.component.html',
  styleUrls: ['./fullviewdata.component.scss']
})
export class FullviewdataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
