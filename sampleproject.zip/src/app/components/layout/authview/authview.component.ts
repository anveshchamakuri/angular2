import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authview',
  templateUrl: './authview.component.html',
  styleUrls: ['./authview.component.scss']
})
export class AuthviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
