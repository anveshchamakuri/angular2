export const UrlconfigService = {
"Baseurl": {
    "baseurl": "https://jsonplaceholder.typicode.com/",
},
"sample": {
  "sampleapi": "posts",
}
}


